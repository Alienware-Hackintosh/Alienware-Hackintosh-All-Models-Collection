directory for built binaries such as SSDT-XOSI.aml
